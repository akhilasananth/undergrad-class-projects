SYSC3303 Assignment 2
Akhila Ananth
100894838

Running Instructions:

-This program is run on eclipse and runs best on JavaSE-1.7
-Please make sure that all of the classes in the source code reqiore pbj package
-Just run test.java to run the program

Files included:

1) Agent.java
2) ChefOne.java
3) ChefTwo.java
4) ChefThree.java
5) test.java

6) agentCollaboration.jpeg
7) chefOneCollaboration.jpeg
8) chefTwoCollaboration.jpeg
9) chefThreeCollaboration.jpeg
10) tableCollaboration.jpeg

11) UML.png
12) UCM.pdf